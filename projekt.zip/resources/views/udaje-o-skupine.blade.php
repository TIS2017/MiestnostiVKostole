@extends('layouts.app')
@section('title','Údaje o skupine')


@section('content')

<section>
    <div class="section padding-bottom">
        <a href="{{ redirect()->back()->getTargetUrl() }}" class="btn-back">naspäť</a>

        @if(!empty($subadmin_data))
            @foreach ($subadmin_data as $data)

            <h1 class="h1-name">{{$data->name}}</h1>
            <table class="color-white-profil">
                <tr>
                    <th class="width-200">VEDÚCI SKUPINY:</th>
                    <td class="width-200">{{$data->firstname}} {{$data->lastname}}</td>
                    @if (Auth::check ())
                        <td rowspan="3" class="width-200">
                    @else
                    <td class="width-200" >
                    @endif
                        <img src="/img/profil.jpg" alt="fotka" width="193" height="209">
                    </td>
                </tr>
                @if (Auth::check ())
                    <tr>
                        <th class="width-200">EMAIL:</th>
                        <td class="width-200">{{$data->email}}</td>
                    </tr>
                    <tr>
                        <th class="width-200">TELEFÓNNE Č.:</th>
                        <td class="width-200">{{$data->tel}}</td>
                    </tr>
                @endif
            </table>


            @endforeach
        @endif

    </div>

    @if (Auth::check ())
    <div>
         <h1 class="h1-text">ČLENOVIA</h1>

                @if(!empty($members))
                @foreach ($members as $member)
                <table class="filtab">
                    <tr>
                    <th class="mena">{{$member->firstname}}  {{$member->lastname}}</th>
                    </tr>          
                </table>
                @endforeach
                @endif

                <p class="vstupdoskup" align="center">
                <button type="submit" class="button-reg-login-udaje btn-profil">VSTÚPIŤ DO SKUPINY</button>
                </p>
    </div>
    @endif

</section>   

@endsection