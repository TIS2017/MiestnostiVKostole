    <div class="table-responzive">
      <table class="mapa" align="center">
  		  <tr>
  		     <th class="pasivna">VRAT.</th>
  		     <th class="zavratnica"><a href="/miestnost">ZAVRAT.</a></th>
  		     <td></td>
  		     <th class="wc">WC</th>
  		     <td></td>
  		     <th class="pasivna" style="width: 80px">47</th>
  		     <th class="m46" style="width: 80px"><a href="/miestnost">46</a></th>
  		     <th class="m45"><a href="/miestnost">45</a></th>
  		     <th class="m44" style="width: 120px"><a href="/miestnost">44</a></th>
  		  </tr>
  		  <tr class="medzera"></tr>
  		  <tr>
  		     <th class="m54"><a href="/miestnost">54</a></th>
  		     <td></td>
  		     <th class="dvor" rowspan="2" colspan="5"><img src="/img/dvor.png" alt="dvor" class="img-responsive section-image"></th>
  		     <td></td>
  		     <th class="kaplnka" rowspan="2"><a href="/miestnost">KAPLNKA</a></th>
  		  </tr>
  		  <tr>
  			  <th class="pasivna">55</th>		  
  		  </tr>
  		  <tr class="medzera"></tr>
  		  <tr>
  		     <th class="caffe"><a href="/miestnost">CAFFE</th>
  		     <th class="refektar" colspan="3"><a href="/miestnost">REFEKTAR</a></th>
  		     <th class="wc">WC</th>
  		     <th class="suteren" colspan="2"><a href="/miestnost">SUTEREN</a></th>
  		     <td></td>
  		     <th class="kostol"><a href="/miestnost">KOSTOL</a></th>
  		  </tr>		
  		</table>
    </div>