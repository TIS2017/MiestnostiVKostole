<!-- Filtracia -->
    <div class="container-fluid section-filtracia">
        <h2 class="h2-text">FILTROVAŤ PODĽA</h2>
        <div clas="row" align="center">
            <div class="col-sm-4 filter-responsive">
                <a href="/miestnost">
                    <img src="<?php echo $miestnost; ?>" alt="miestnost" border="0">
                </a>
            </div>
            <div class="col-sm-4 filter-responsive">
                <a href="/cas">
                    <img src="<?php echo $cas; ?>" alt="cas" border="0">
                </a>
            </div>
            <div class="col-sm-4 filter-responsive">
                <a href="/skupina">
                    <img src="<?php echo $skupina; ?>" alt="skupina" border="0">
                </a>
            </div>
        </div>
    </div>