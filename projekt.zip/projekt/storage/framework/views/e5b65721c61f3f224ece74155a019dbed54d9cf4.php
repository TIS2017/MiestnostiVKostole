<?php $__env->startSection('title','Vytvorenie skupiny'); ?>

<?php $__env->startSection('content'); ?>
<section>
	<div class="section">
    <a href="/profil" class="btn-back">naspäť</a>
    <?php echo $__env->make('layouts.includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<h1 class="center h1-text2">
		 	<span class="h1-a active">VYTVORENIE SKUPINY</span>
	    </h1>
	    	<form class="formular" method="POST" action="/profil/vytvor-skupinu">
	    	<?php echo e(csrf_field()); ?>

	          	<p class="formular" align="center">
			    	<input type="text" placeholder="NÁZOV SKUPINY" name="name" value="<?php echo e(old('name')); ?>" required><br>
			    	<select class="vyber" name="subadmin" id="meno">
			            <option value="vyber">--VYBER VEDÚCEHO--</option>
			            <?php if(!empty($users)): ?>
		                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></option>
		                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                <?php endif; ?>
			        </select><br>
		    		<button type="submit" class="button-reg-login-udaje">REGISTER</button>
	          	</p>
    		</form>
    </div>


</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>