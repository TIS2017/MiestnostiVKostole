<?php $__env->startSection('title','Profil'); ?>


<?php $__env->startSection('content'); ?>

<section>
    <div class="alert-messages text-center"></div>
    <div class="section">
        <a href="/" class="btn-back">naspäť</a>
        <h1 class="h1-name"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastame); ?></h1>

         <table class="color-white-profil" align="center">
            <tr>
                <th class="width-200">EMAIL:</th>
                <td><?php echo e(Auth::user()->email); ?></td>
                <td rowspan="2">
                    <img src="/img/profil.jpg" alt="fotka" width="193" height="209">
                </td>
             </tr>
             <tr>
                <th class="width-200">TELEFÓNNE Č.:</th>
                <td><?php echo e(Auth::user()->tel); ?></td>
             </tr>
         </table>

         <p align="center" class="padding-top">
            <button type="submit" class="button-reg-login-udaje">UPRAVIŤ ÚDAJE</button>
        </p>
    </div>
    <div class="padding padding-top">
        <h1 class="h1-text">MOJE SKUPINY</h1>
        <table class="filtab">
            <tr>

                <?php if(!empty($mygroups)): ?>
                    <?php $__currentLoopData = $mygroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="filter">SKUPINA</th>
                        <th class="filter"><?php echo e($group->name); ?></th>
                        <th class="filter">11:00 ??? </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if( Auth::user()->is_admin == true): ?> 
                <?php //neskor dat aj moznost spravovania pre naduzivatela 
                ?>
                    <th class="filter">
                        <a href="/sprava-skupin" class="btn-fix btn-back">spravovať</a>
                    </th>
                    <th class="filter"><button type="submit" class="btn-fix btn-back">ZRUŠIŤ</button></th>
                <?php endif; ?>
            </tr>      
        </table>

        <?php if( Auth::user()->is_admin == true): ?>
            <p align="center">
                <a href="/profil/vytvor-skupinu" class="button-reg-login-udaje btn-profil">VYTVORIŤ SKUPINU</a><br>
                <a href="/profil/vytvor-clena" class="button-reg-login-udaje btn-profil">VYTVORIŤ ČLENA</a>
            </p>
        <?php endif; ?>
    </div>
</section>   

    <script type="text/javascript">
        function showAlert(message) {
            var htmlAlert = '<div class="alert alert-success">' + message + '</div>';
            $(".alert-messages").prepend(htmlAlert);
            $(".alert-messages .alert").first().hide().fadeIn(200).delay(2000).fadeOut(1000, function () { $(this).remove(); });
        }
    </script>
    <?php if(session('Status')): ?>
        <script type="text/javascript">
            showAlert("Registrácia člena prebehla úspešne.");
        </script>
    <?php elseif(session('Skupina')): ?>
        <script type="text/javascript">
            showAlert("Skupina bola úspešne vytvorená.");
        </script>
    <?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>