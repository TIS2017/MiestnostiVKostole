<?php $__env->startSection('title','Vytvorenie člena'); ?>

<?php $__env->startSection('content'); ?>
<section>
	<div class="section">
    <a href="/profil" class="btn-back">naspäť</a>
    	<?php echo $__env->make('layouts.includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<h1 class="center h1-text2">
		 	<span class="h1-a active">VYTVORENIE ČLENA</span>
	    </h1>
	    <form class="formular" method="POST" action="/profil/vytvor-clena">
	    <?php echo e(csrf_field()); ?>

	        <p class="formular" align="center">
			    <input type="text" placeholder="MENO" name="firstname" value="<?php echo e(old('firstname')); ?>" required>
		    	<input type="text" placeholder="EMAIL" name="email" value="<?php echo e(old('email')); ?>"><br>
		    	<input type="text" placeholder="PRIEZVISKO" name="lastname" value="<?php echo e(old('lastname')); ?>" required>
		    	<input type="text" placeholder="PRIHLASOVACIE MENO" name="username" value="<?php echo e(old('username')); ?>" required><br>
		    	<input type="text" placeholder="TELEFÓNNE ČÍSLO" name="tel" value="<?php echo e(old('tel')); ?>">
	    		<input type="password" placeholder="HESLO" name="password" required><br>
	          	<select class="vyber" name="skupina" id="skupina">
			        <option value="vyber">--Vyber skupinu--</option>
			        <?php if(!empty($groups)): ?>
	                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
	                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                <?php endif; ?>
			    </select><br>
		    	<button type="submit" class="button-reg-login-udaje">REGISTER</button>
	        </p>
    	</form>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>