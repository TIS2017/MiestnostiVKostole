<?php $__env->startSection('title','Údaje o skupine'); ?>
<?php $__env->startSection('content'); ?>

<?php if($is_subadmin>0): ?>
<article>
    <div class="section">
        <a href="/udaje-o-skupine" class="btn-back">naspäť</a>
        <h1 class="h1-name"><?php echo e($groupName); ?></h1>
    </div>
</article>
<section>
  <div class="container-fluid section-filtracia">
      
    <h1 class="h1-text">ČLENOVIA</h1>
    <?php if(!empty($members)): ?>
        <?php if($members->count()==0): ?>
            <p align=center>Skupina nemá žiadnych členov.</p>
        <?php else: ?>
            <table class="filtab" align="center">
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th class="width-200"><?php echo e($member->firstname); ?>  <?php echo e($member->lastname); ?></th>
                    <th class="width-200"><?php echo e($member->email); ?></th>
                    <th class="width-200"><?php echo e($member->tel); ?></th>
              </tr>     
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
            </table>  
        <?php endif; ?>
    <?php endif; ?>
  </div>
  <div class="content">
    <div class="content-second">
    </div>
  </div>
    <div class="padding">       
        <h1 class="h1-text">ŽIADOSTI</h1>
        <?php if(!empty($requests)): ?>
            <?php if($requests->count()==0): ?>
                <p align=center>V tejto skupine sa nenachádzajú žiadne žiadosti.</p>
            <?php else: ?>
                <table class="filtab">
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th class="width-200"><?php echo e($request->firstname); ?>  <?php echo e($request->lastname); ?></th>
                        <th class="width-200">žiadosť o pridanie</th>
                        <form method="post" action="/udaje-o-skupine/<?php echo e($groupName); ?>/<?php echo e($request->group_id); ?>" >
                        <?php echo e(csrf_field()); ?>

                            <th class="filter"><button type="submit" class="btn-fix btn-back">schváliť</button></th>
                        </form>
                        <form method="post" action="/udaje-o-skupine/<?php echo e($groupName); ?>/<?php echo e($request->group_id); ?>" >
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                            <th class="filter"><button type="submit" class="btn-fix btn-back">zamietnuť</button></th>
                        </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <?php else: ?>
    <section>
        <div class="alert-messages text-center"></div>
        <div class="section padding-bottom">
            <a href="/udaje-o-skupine" class="btn-back">naspäť</a>

            <?php if(!empty($subadmin_data)): ?>
                <?php if($subadmin_data->count()==0): ?>
                    <h1 class="h1-name" align=center>Skupina neexistuje.</h1>
                <?php else: ?>
                    <?php $__currentLoopData = $subadmin_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h1 class="h1-name"><?php echo e($groupName); ?></h1>
                        <table class="color-white-profil">
                            <tr>
                                <th class="width-200">VEDÚCI SKUPINY:</th>
                                <td class="width-200"><?php echo e($data->firstname); ?> <?php echo e($data->lastname); ?></td>
                                <?php if(Auth::check ()): ?>
                                    <td rowspan="3" class="width-200">
                                <?php else: ?>
                                    <td class="width-200" >
                                <?php endif; ?>
                                    <img src="/img/profil.jpg" alt="fotka" width="193" height="209">
                                </td>
                            </tr>
                            <?php if(Auth::check ()): ?>
                                <tr>
                                    <th class="width-200">EMAIL:</th>
                                    <td class="width-200"><?php echo e($data->email); ?></td>
                                </tr>
                                <tr>
                                    <th class="width-200">TELEFÓNNE Č.:</th>
                                    <td class="width-200"><?php echo e($data->tel); ?></td>
                                </tr>
                            <?php endif; ?>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if(Auth::check () && $subadmin_data->count()!=0): ?>
        <div>
             <h1 class="h1-text">ČLENOVIA</h1>
                <?php if(!empty($members)): ?>
                    <?php if($members->count()==0): ?>
                        <p align=center>Skupina nemá žiadnych členov.</p>
                    <?php else: ?>
                        <table class="filtab">
                        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <th class="mena"><?php echo e($member->firstname); ?>  <?php echo e($member->lastname); ?></th>
                            </tr>          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    <?php endif; ?>

                    <?php if($is_member < 1): ?>
                        <form method="post" action="/udaje-o-skupine/<?php echo e($groupName); ?>" >
                        <?php echo e(csrf_field()); ?>

                            <p class="vstupdoskup" align="center">
                                <button type="submit" class="button-reg-login-udaje btn-profil">VSTÚPIŤ DO SKUPINY</button>
                            </p>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</section> 
    <script type="text/javascript">
        function showAlert(message) {
            var htmlAlert = '<div class="alert alert-success">' + message + '</div>';
            $(".alert-messages").prepend(htmlAlert);
            $(".alert-messages .alert").first().hide().fadeIn(200).delay(2000).fadeOut(1000, function () { $(this).remove(); });
        }
    </script>
    <?php if(session('Status')): ?>
        <script type="text/javascript">
            showAlert("Žiadosť bola úspešne odoslaná.");
        </script>
    <?php endif; ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>