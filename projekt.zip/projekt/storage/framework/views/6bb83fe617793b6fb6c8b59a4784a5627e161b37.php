<?php $__env->startSection('title','Miestnosť'); ?>

<?php $__env->startSection('content'); ?>


<article>
	<?php echo $__env->make('layouts.includes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</article>
<section>
	<?php 
    	$miestnost="/img/miestnost.png";
    	$cas="/img/cas2.png";
    	$skupina="/img/skupina2.png";
	?>
	<?php echo $__env->make('layouts.includes.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="content">
		<div class="content-second">
		 	<form method="post" action="<?php echo e(action('FilterController@filterRoom')); ?>">
				<?php echo e(csrf_field()); ?>

			 	<p class="filtre" align="center">
			 		<select  class="vyber" name="room" id="room">
						<option value="vyber"> --Vyber miestnosť-- </option>
						<?php $__currentLoopData = $roomlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value=<?php echo e($item); ?>>  <?php echo e($item); ?>  </option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
			    	<button class="button-filter" type="submit">FILTRUJ</button>
		    	</p>
	    	</form>
	</div></div>
		<div class="padding">
	    <!-- Mapa -->
		<?php echo $__env->make('layouts.includes.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<!-- Nazvy miestnosti -->
		<?php if(!empty($rooms) && !empty($roomName) ): ?>
		
			<h1 class="h1-text"><?php echo e($roomName); ?></h1>
			<ul class="nav nav-pills nav-justified">
			<?php $__currentLoopData = $collect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class=""><a data-toggle="tab" href="#<?php echo e($day); ?>"><?php echo e($day); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	</ul>
		 	
			 <div class="tab-content">
			<?php $__currentLoopData = $collect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div id="<?php echo e($day); ?>" class="tab-pane">

					<table class="filtab">
						<thead>
					 		<tr>
							   	<th class="filter"> od | do </th>
							   	<th class="filter">skupina</th>  
					  		</tr>
						 </thead>
						 
						<?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<!--p><?php echo e($day); ?> == <?php echo e($collect->get($room->day)); ?></p>
									<p><?php echo e($t); ?> == <?php echo e($room->time); ?></p-->

								<?php if($day==$collect->get($room->day) && $t==$room->time): ?>

							    	<td> <?php echo e($room->time); ?> - <?php echo e(\Illuminate\Support\Str::limit($room->end_time, $limit = 5, $end = '')); ?> </td>
							    	<td><a href="/udaje-o-skupine/<?php echo e($room->group); ?>" class="btn-hover"><?php echo e($room->group); ?></a></td>
							  	<?php else: ?>
							    		<td> <?php echo e($t); ?> - <?php echo e($key==20 ? "21:00" : $times->get($key+1)); ?> </td>
							    		<td> - </td>

										<?php if( Auth::check() && Auth::user()->is_admin == true || $is_subadmin > 0): ?>
											<td><button  
												data-roomname="<?php echo e($roomName); ?>" 
												data-userid="<?php echo e(Auth::user()->id); ?>"
												data-subadming="<?php echo e($subadmin_groups); ?>"
												class="two" 
												data-toggle="modal" 
												data-target="#rezervacia" 
												type="button">Pridať </button>
											</td>
							    		<?php endif; ?>
							  	<?php break; ?>;
							  	<?php endif; ?>
							  	</tr>
				  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  		</table>
		  		</div>
		  	
		 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	</div>
		<?php endif; ?>
		 </div>
		 

		<?php echo $__env->make('rezervacia-miestnosti', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>