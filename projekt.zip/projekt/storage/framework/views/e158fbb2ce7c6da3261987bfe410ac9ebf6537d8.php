<nav>
	<a href="/registracia">REGISTER</a> 
	/
	<a href="/prihlasenie">LOG IN</a>
</nav> 