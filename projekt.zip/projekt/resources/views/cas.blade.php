@extends('layouts.app')
@section('title','Čas')

@section('content')

<article></article>
<section>
	<div class="alert-messages text-center"></div>
	<?php 
    	$miestnost="/img/miestnost2.png";
    	$cas="/img/cas.png";
    	$skupina="/img/skupina2.png";
	?>
	@include('layouts.includes.filter')

	<div class="content">
		<div class="content-second">
		 	<form method="post" action="{{action('FilterController@filterTime')}}">
			{{ csrf_field() }}
			 	<p align="center">
			 		<span class="text">DEŇ:</span>
			        <select class="den" name="den" id="den">
			            <option value="vyber">--Vyber deň--</option>
			            <option value="1">Pondelok</option>
			            <option value="2">Utorok</option>
			            <option value="3">Streda</option>
			            <option value="4">Štvrtok</option>
			            <option value="5">Piatok</option>
			            <option value="6">Sobota</option>
			            <option value="7">Nedeľa</option>
			        </select>

			        <span class="text">ČAS:</span> 
			        <select class="od" name="od" id="od">
						<option value="08:00">--od--</option>
						@for ($i = 8; $i < 22; $i++)
							@if ($i < 10)
								<option value="{{ "0".$i.":00" }}">0{{$i.":00"}}</option>
							@else
								<option value="{{ $i.":00" }}">{{$i.":00"}}</option>
							@endif

						@endfor
					</select>
			        <select class="do" name="do" id="do">
						<option value="21:00">--do--</option>
						@for ($i = 8; $i < 22; $i++)
							@if ($i < 10)
								<option value="{{ "0".$i.":00" }}">0{{$i.":00"}}</option>
							@else
								<option value="{{ $i.":00" }}">{{$i.":00"}}</option>
							@endif
						@endfor
					</select>

    				<button class="button-filter" type="submit">FILTRUJ</button>
		    	</p>
	    	</form>
	</div></div>
	<div class="padding">
	    <!-- Mapa -->
		@include('layouts.includes.map')

		<!-- Nazvy miestnosti a skupiny -->

		@if(!empty($times))
		
			<h1 class="h1-text">{{ $day or 'Pondelok' }} {{ $from or '08:00' }} - {{ $to or '21:00' }}</h1>
			<table class="filtab">
				<thead>
			 		<tr>
						   <th class="filter">čas</th>
						   <th class="filter">miestnosť</th>
	   					<th class="filter">skupina</th>
			  		</tr>
				  </thead>
				  

				  @foreach ($filtered_time as $key=>$t)
				  	<?php $gtime = null; ?>
					@if(!empty($times))

						@foreach($times as $time)
							<tr>
								@if($day==$collect->get($time->day) && $t==$time->time)
								<td> {{ $t }} - {{ $key== $filtered_time->last()  ? '21:00' : $filtered_time->get($key+1) }} </td>
		    					<td> {{ $time->room }}</td>
								<td><a href="/udaje-o-skupine/{{ $time->group }}" class="btn-hover">{{ $time->group }}</a></td>
								<td> - </td>
								@endif
							</tr>
						@endforeach
						  
					  
						@if($gtime == null)
							<tr> 
								@if($t != $filtered_time->last())
									<td> {{ $t }} - {{ $key== $filtered_time->last()  ? null : $filtered_time->get($key+1) }} </td>
									<td> - </td>
									<td> - </td>
									@if( Auth::check() && Auth::user()->is_admin == true || $is_subadmin > 0)
											<td><button  
												data-userid="{{ Auth::user()->id }}"
												data-subadming="{{$subadmin_groups}}"
												data-od = "{{$t}}"
												data-den = "{{$day}}"
												data-roomlist = {{$roomlist}}
												data-click = "true"
												class="two" 
												data-toggle="modal"
												data-target="#rezervacia" 
												type="button">Pridať </button>
											</td>
									@endif
								@endif
							</tr>
						@endif



					@endif




				  @endforeach

				  





		 	</table>
		@endif
		 </div>
		 
		 @include('rezervacia-miestnosti')

</section>


<script type="text/javascript">
	function showAlert(message) {
		var htmlAlert = '<div class="alert alert-success">' + message + '</div>';
		$(".alert-messages").prepend(htmlAlert);
		$(".alert-messages .alert").first().hide().fadeIn(200).delay(2000).fadeOut(1000, function () { $(this).remove(); });
	}
</script>
@if(session('Status'))
	<script type="text/javascript">
		showAlert("Rezervácia bola úspešná.");
	</script>
@endif

@endsection