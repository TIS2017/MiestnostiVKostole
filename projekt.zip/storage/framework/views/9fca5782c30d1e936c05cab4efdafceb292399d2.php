<?php $__env->startSection('title','Údaje o skupine'); ?>


<?php $__env->startSection('content'); ?>

<section>
    <div class="section padding-bottom">
        <a href="<?php echo e(redirect()->back()->getTargetUrl()); ?>" class="btn-back">naspäť</a>

        <?php if(!empty($subadmin_data)): ?>
            <?php $__currentLoopData = $subadmin_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <h1 class="h1-name"><?php echo e($data->name); ?></h1>
            <table class="color-white-profil">
                <tr>
                    <th class="width-200">VEDÚCI SKUPINY:</th>
                    <td class="width-200"><?php echo e($data->firstname); ?> <?php echo e($data->lastname); ?></td>
                    <?php if(Auth::check ()): ?>
                        <td rowspan="3" class="width-200">
                    <?php else: ?>
                    <td class="width-200" >
                    <?php endif; ?>
                        <img src="/img/profil.jpg" alt="fotka" width="193" height="209">
                    </td>
                </tr>
                <?php if(Auth::check ()): ?>
                    <tr>
                        <th class="width-200">EMAIL:</th>
                        <td class="width-200"><?php echo e($data->email); ?></td>
                    </tr>
                    <tr>
                        <th class="width-200">TELEFÓNNE Č.:</th>
                        <td class="width-200"><?php echo e($data->tel); ?></td>
                    </tr>
                <?php endif; ?>
            </table>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>

    <?php if(Auth::check ()): ?>
    <div>
         <h1 class="h1-text">ČLENOVIA</h1>

                <?php if(!empty($members)): ?>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <table class="filtab">
                    <tr>
                    <th class="mena"><?php echo e($member->firstname); ?>  <?php echo e($member->lastname); ?></th>
                    </tr>          
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <p class="vstupdoskup" align="center">
                <button type="submit" class="button-reg-login-udaje btn-profil">VSTÚPIŤ DO SKUPINY</button>
                </p>
    </div>
    <?php endif; ?>

</section>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>