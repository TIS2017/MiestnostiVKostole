<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\View;

class InfoController extends Controller
{
    public function showGroupInfo($groupname){
        
        $subadmin_data = DB::table('groups')
					->join('users', 'groups.subadmin_id', '=', 'users.id')
                    ->select('groups.name as name', 'users.firstname as firstname', 'users.lastname as lastname', 'users.tel as tel', 'users.email as email')
                    ->where('groups.name', '=', $groupname)
                    ->get();

        $members = DB::table('users')
                    ->join('group_connects', 'group_connects.user_id', '=', 'users.id')
                    ->join('groups', 'group_connects.group_id', '=', 'groups.id')
                    ->select('users.firstname as firstname', 'users.lastname as lastname')
                    ->where('groups.name', '=', $groupname)
                    ->get();

        return View::make('udaje-o-skupine')->with('subadmin_data', $subadmin_data)->with('members', $members);
    }


    public function index($groupname)
{
    var_dump($groupname);
}




}
